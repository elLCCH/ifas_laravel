<?php

namespace App\Http\Controllers;

use App\Models\Adquisiciones;
use Illuminate\Http\Request;

class AdquisicionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Adquisiciones  $adquisiciones
     * @return \Illuminate\Http\Response
     */
    public function show(Adquisiciones $adquisiciones)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Adquisiciones  $adquisiciones
     * @return \Illuminate\Http\Response
     */
    public function edit(Adquisiciones $adquisiciones)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Adquisiciones  $adquisiciones
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Adquisiciones $adquisiciones)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Adquisiciones  $adquisiciones
     * @return \Illuminate\Http\Response
     */
    public function destroy(Adquisiciones $adquisiciones)
    {
        //
    }
}
